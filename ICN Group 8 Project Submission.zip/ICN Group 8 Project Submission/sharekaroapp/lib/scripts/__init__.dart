import 'dart:io';

InternetAddress HOST = InternetAddress("192.168.43.171");
const PORT=8082;
const QUIT="QUIT";
const CONNECTED=false;
const RECEIVING=false;
const FORMAT="utf-8";